// prototypes for test event checkers

boolean Check4ButtonPushed(void); //Post event: BUTTON_PUSHED
boolean Check4IRUpLimitSwitch(void);//Post event: IR_UP_LIMIT_SWITCH
boolean Check4IRDownLimitSwitch(void);//Post event: IR_DOWN_LIMIT_SWITCH
boolean Check4CubeCorrect(void);//Post event: CUBE_CORRECT, CUBE_INCORRECT





