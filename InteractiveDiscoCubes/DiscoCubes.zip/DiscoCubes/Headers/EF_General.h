#ifndef EF_General_H
#define EF_General_H

#define ARRAY_SIZE(x)  (sizeof(x)/sizeof(x[0]))

#endif//EF_General_H